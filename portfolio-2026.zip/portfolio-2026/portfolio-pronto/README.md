# Portfólio 2026 — versão pronta

Tudo o que muda no site fica em **js/data.js**. Não precisa mexer no HTML, no CSS nem no `main.js`.
Abra o `data.js` no **VS Code** e cuide para não apagar aspas `"` e vírgulas `,`.

Esta versão tem **só os trabalhos que já têm foto ou vídeo**. Os que faltam estão na versão completa; quando as imagens chegarem, copie o bloco do trabalho de lá para cá.


## 1. Adicionar ou completar um trabalho
Dentro de `projetos: [ ... ]`, cada trabalho é um bloco `{ ... }` separado por vírgula. Copie um bloco, troque `id` (sem espaços nem acentos), `titulo`, `categoria` (igual a uma das `categorias`), `bimestre`, `descricao` e `objetivo`. Se quiser os integrantes no trabalho, use `participantes: ["i1","i3"]` (os `id` de `integrantes`).

## 2. Adicionar imagens
1. Crie a pasta `assets/images/projects/nome-do-trabalho/` e coloque as fotos (`.jpg`, até 1600 px de largura).
2. Em `imagens`, liste cada foto com `src` e `alt`. O `alt` descreve o que se vê na foto, e aparece como legenda na foto ampliada. Escreva de verdade: o que é, cores, o que está acontecendo.
A **primeira** foto vira a capa do card. Se as imagens não são de vocês, escreva a fonte em `credito: "..."`: o site mostra em "Créditos". Para vídeos: `videos: [{ src: "...mp4", poster: "...jpg", alt: "...", legenda: "..." }]`.

## 3. Integrantes
Em `integrantes`, edite `nome`. `apresentacao` e `contribuicao` são opcionais (vazios, não aparecem). Para foto, salve em `assets/images/members/` e escreva `foto: "assets/images/members/ana.jpg"`; sem foto, aparecem as iniciais.

## 4. Informações gerais
Em `site`: nome da turma (`grupo`), escola, ano, subtítulo, textos do "Sobre" e mensagem final. O título que o Google mostra fica no `<title>` do `index.html`.

## 5. Áudio do podcast
Salve o MP3 em `assets/podcast/podcast.mp3` (já está lá). Se o podcast estiver em outro serviço, deixe `audio` vazio e cole o código de incorporação em `embed`.

## 6. Capa do podcast
Troque `assets/podcast/cover.jpg` (quadrada, ex.: 800×800) ou mude o caminho em `capa`.

## 7. Testar no computador
Dois cliques no `index.html`. Para um teste mais fiel, use a extensão **Live Server** do VS Code.

## 8. Publicar (grátis)
**Netlify Drop:** app.netlify.com/drop, arraste a pasta inteira e receba o link. **GitHub Pages:** suba a pasta e ative em *Settings → Pages*.
Depois de publicar, no `index.html` descomente `canonical` e `og:image` e coloque o endereço real.
