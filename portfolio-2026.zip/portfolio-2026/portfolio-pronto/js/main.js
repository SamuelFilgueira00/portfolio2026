(() => {
  const D = window.PORTFOLIO, $ = s => document.querySelector(s);
  const h = (tag, attrs = {}, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, v);
    kids.flat().forEach(c => e.append(c));
    return e;
  };
  const membros = Object.fromEntries(D.integrantes.map(m => [m.id, m]));
  const nomes = ids => ids.map(i => membros[i]?.nome).filter(Boolean).join(", ");
  const iniciais = n => { const p = n.match(/\p{L}+/gu) || ["?"]; return (p[0][0] + (p.length > 1 ? p[1][0] : "")).toUpperCase(); };

  /* Revelar ao rolar */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .12 });
  const revelar = () => document.querySelectorAll(".reveal:not(.in)").forEach(e => io.observe(e));

  /* Foto que falha ao carregar vira um bloco neutro (sem imagem quebrada) */
  document.addEventListener("error", e => {
    if (e.target.tagName !== "IMG" || e.target.id === "lbImg") return;
    e.target.replaceWith(h("div", { class: "sem-foto", role: "img", "aria-label": e.target.alt || "Foto indisponível" }, "Foto indisponível"));
  }, true);

  /* Foto em pé (tirada com o celular) aparece inteira, sem corte */
  document.addEventListener("load", e => { if (e.target.tagName === "IMG" && e.target.naturalHeight > e.target.naturalWidth) e.target.classList.add("retrato"); }, true);

  /* Textos simples */
  document.querySelectorAll("[data-bind]").forEach(e => e.textContent = D.site[e.dataset.bind]);
  $("#sobreTexto").append(...D.site.sobre.map(t => h("p", {}, t)));
  $("#rodapeNomes").textContent = D.integrantes.map(m => m.nome).join(" · ");

  /* Integrantes */
  $("#membros").append(...D.integrantes.map(m => h("article", { class: "membro reveal" },
    m.foto ? h("img", { src: m.foto, alt: m.fotoAlt || "Foto de " + m.nome, class: "m-foto", width: 800, height: 1000, loading: "lazy", decoding: "async" })
           : h("div", { class: "iniciais", role: "img", "aria-label": "Sem foto: iniciais de " + m.nome }, iniciais(m.nome)),
    h("h3", {}, m.nome), m.apresentacao ? h("p", {}, m.apresentacao) : "",
    m.contribuicao ? h("p", { class: "contrib" }, h("strong", {}, "No grupo: "), m.contribuicao) : "")));

  /* Player do podcast: o <audio> nativo faz o trabalho; os botões são nossos para combinar com o site */
  function criarPlayer(src) {
    const svg = d => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
    const cor = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"';
    const ico = { play: svg('<path d="M8 5v14l11-7z"/>'), pause: svg('<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>'),
      som: svg(`<path d="M3 9v6h4l5 4V5L7 9z"/><path d="M16 8.5a5 5 0 010 7" ${cor}/>`), mudo: svg(`<path d="M3 9v6h4l5 4V5L7 9z"/><path d="M16 9l5 6M21 9l-5 6" ${cor}/>`) };
    const btn = (cls, label, html) => { const b = h("button", { type: "button", class: cls, "aria-label": label }); b.innerHTML = html; return b; };
    const t = s => isFinite(s) ? Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0") : "0:00";
    const audio = h("audio", { preload: "metadata", src });
    const play = btn("p-play", "Tocar episódio", ico.play), menos = btn("p-skip", "Voltar 10 segundos", "−10"), mais = btn("p-skip", "Avançar 10 segundos", "+10"), mudo = btn("p-mudo", "Silenciar", ico.som);
    const prog = h("input", { class: "p-prog", type: "range", min: 0, max: 100, step: 0.1, value: 0, "aria-label": "Progresso do episódio" });
    const vol = h("input", { class: "p-vol", type: "range", min: 0, max: 1, step: 0.05, value: 1, "aria-label": "Volume" });
    const atual = h("span", {}, "0:00"), total = h("span", {}, "0:00");
    const erro = h("p", { class: "p-erro", role: "alert", hidden: "" }, "Não foi possível carregar o áudio.");
    const box = h("div", { class: "player", role: "group", "aria-label": "Player do podcast" }, audio,
      h("div", { class: "p-topo" }, h("span", { class: "eq", "aria-hidden": "true" }, h("i"), h("i"), h("i"), h("i")), h("span", {}, atual, " / ", total)), prog,
      h("div", { class: "p-ctrl" }, menos, play, mais, h("span", { class: "p-som" }, mudo, vol)), erro);
    const marca = () => { const p = audio.duration ? audio.currentTime / audio.duration * 100 : 0; prog.value = p; prog.style.setProperty("--p", p + "%");
      atual.textContent = t(audio.currentTime); prog.setAttribute("aria-valuetext", t(audio.currentTime) + " de " + t(audio.duration)); };
    audio.onloadedmetadata = () => { total.textContent = t(audio.duration); marca(); };
    audio.ontimeupdate = marca;
    audio.onplay = audio.onpause = () => { const on = !audio.paused; box.classList.toggle("tocando", on); play.innerHTML = on ? ico.pause : ico.play; play.setAttribute("aria-label", on ? "Pausar episódio" : "Tocar episódio"); };
    audio.onended = () => { audio.currentTime = 0; };
    audio.onerror = () => { erro.hidden = false; };
    audio.onvolumechange = () => { const m = audio.muted || audio.volume === 0; mudo.innerHTML = m ? ico.mudo : ico.som; mudo.setAttribute("aria-label", m ? "Ativar som" : "Silenciar"); };
    play.onclick = () => audio.paused ? audio.play().catch(() => {}) : audio.pause();
    menos.onclick = () => { audio.currentTime = Math.max(0, audio.currentTime - 10); };
    mais.onclick = () => { audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 10); };
    prog.oninput = () => { audio.currentTime = prog.value / 100 * (audio.duration || 0); marca(); };
    vol.oninput = () => { audio.volume = vol.value; audio.muted = false; vol.style.setProperty("--p", vol.value * 100 + "%"); };
    vol.style.setProperty("--p", "100%");
    mudo.onclick = () => { audio.muted = !audio.muted; };
    return box;
  }

  /* Podcast */
  const P = D.podcast;
  $("#podTitulo").textContent = P.titulo;
  $("#podDesc").textContent = P.descricao;
  $("#podPart").textContent = nomes(P.participantes) ? "Com " + nomes(P.participantes) : "";
  $("#podPart").hidden = !nomes(P.participantes);
  $("#podExtra").append(...P.informacoes.map(t => h("li", {}, t)));
  $("#podCapa").append(P.capa ? h("img", { src: P.capa, alt: P.capaAlt, loading: "lazy", decoding: "async" })
                              : h("div", { class: "sem-foto", role: "img", "aria-label": "Capa do podcast ainda não adicionada" }, "Capa do podcast"));
  const pl = $("#podPlayer");
  if (P.audio) pl.append(criarPlayer(P.audio));
  else if (P.embed) pl.innerHTML = P.embed;
  else pl.append(h("p", { class: "vazio-mini" }, "O episódio será publicado aqui em breve."));

  /* Galeria + filtros */
  const grade = $("#grade"), vazio = $("#vazio"), st = { cat: "todos", mem: "todos", bim: "todos" };
  const card = p => {
    const f = p.imagens?.[0] || (p.videos?.[0]?.poster && { src: p.videos[0].poster, alt: p.videos[0].alt });
    const b = h("button", { class: "card reveal", "data-id": p.id, type: "button", "aria-label": "Abrir " + p.titulo },
      h("figure", {}, f ? h("img", { src: f.src, alt: f.alt, class: f.ajuste === "natural" ? "natural" : f.ajuste ? "retrato" : null, loading: "lazy", decoding: "async" }) : h("div", { class: "sem-foto" }, "Sem foto")),
      h("h3", {}, p.titulo), h("p", { class: "cat" }, p.categoria));
    b.onclick = () => abrir(p);
    return b;
  };
  function desenhar() {
    const lista = D.projetos.filter(p => (st.cat === "todos" || p.categoria === st.cat) && (st.mem === "todos" || p.participantes?.includes(st.mem)) && (st.bim === "todos" || p.bimestre === st.bim));
    grade.replaceChildren(...lista.map(card));
    vazio.hidden = lista.length > 0;
    vazio.textContent = D.projetos.length ? "Nada por aqui com esse filtro." : "Os trabalhos serão publicados aqui em breve.";
    grade.classList.remove("saindo"); revelar();
  }
  function filtrar() { grade.classList.add("saindo"); setTimeout(desenhar, 180); }
  if (D.projetos.length) {
    $("#filtros").hidden = false;
    const chips = $("#chips");
    chips.append(...["todos", ...D.categorias].map(c => {
      const b = h("button", { type: "button", class: "chip", "aria-pressed": c === "todos" }, c === "todos" ? "Todos" : c);
      b.onclick = () => { st.cat = c; chips.querySelectorAll("button").forEach(x => x.setAttribute("aria-pressed", x === b)); filtrar(); };
      return b;
    }));
    /* Seletores só aparecem quando existem dados para filtrar */
    const seletor = (idSel, idLbl, opcoes, chave) => {
      const sel = $(idSel);
      if (opcoes.length < 2) return ($(idLbl).hidden = true);
      sel.append(h("option", { value: "todos" }, "Todos"), ...opcoes.map(o => h("option", { value: o[0] }, o[1])));
      sel.onchange = () => { st[chave] = sel.value; filtrar(); };
    };
    const bims = [...new Set(D.projetos.map(p => p.bimestre).filter(Boolean))];
    const comMembros = D.integrantes.filter(m => D.projetos.some(p => p.participantes?.includes(m.id)));
    seletor("#selBim", "#lblBim", bims.map(b => [b, b]), "bim");
    const preench = D.projetos.filter(p => p.participantes?.length).length >= D.projetos.length / 2;   /* só aparece quando metade dos trabalhos tem integrantes */
    seletor("#selMembro", "#lblMembro", preench ? comMembros.map(m => [m.id, m.nome]) : [], "mem");
  }

  /* Capa: os trabalhos por bimestre, como no quadro da sala */
  function irPara(id) {
    st.cat = st.bim = st.mem = "todos";
    document.querySelectorAll("#chips button").forEach((b, i) => b.setAttribute("aria-pressed", i === 0));
    document.querySelectorAll(".selects select").forEach(s => s.value = "todos");
    desenhar();
    const c = grade.querySelector(`[data-id="${id}"]`); if (!c) return;
    c.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
    c.focus({ preventScroll: true }); c.classList.add("destaque"); setTimeout(() => c.classList.remove("destaque"), 1800);
  }
  const quadro = $("#quadro");
  [...new Set(D.projetos.map(p => p.bimestre).filter(Boolean))].forEach(b => quadro.append(h("div", {}, h("p", { class: "q-bim" }, b),
    h("ul", {}, ...D.projetos.filter(p => p.bimestre === b).map(p => { const a = h("a", { href: "#projetos" }, p.titulo);
      a.onclick = e => { e.preventDefault(); irPara(p.id); }; return h("li", {}, a); })))));
  quadro.hidden = !quadro.children.length;

  /* Detalhe do projeto e foto ampliada (elemento <dialog> nativo) */
  const dlg = $("#detalhe"), lb = $("#lightbox"); let fotos = [], pos = 0;
  function abrir(p) {
    $("#dTitulo").textContent = p.titulo; $("#dCat").textContent = p.categoria;
    const linha = (t, v) => v ? [h("dt", {}, t), h("dd", {}, v)] : [];
    $("#dInfo").replaceChildren(...linha("Integrantes", nomes(p.participantes || [])), ...linha("Período", p.bimestre), ...linha("Data", p.data), ...linha("Descrição", p.descricao), ...linha("Objetivo", p.objetivo), ...linha("Créditos", p.credito));
    fotos = p.imagens || [];
    $("#dVideo").replaceChildren(...(p.videos || []).map(v => h("figure", { class: "d-video" }, h("video", { controls: "", preload: "metadata", playsinline: "", poster: v.poster, src: v.src }, "Seu navegador não toca este vídeo."), h("figcaption", { class: "legenda" }, v.legenda))));
    $("#dFotos").replaceChildren(...fotos.map((f, i) => {
      const b = h("button", { type: "button", "aria-label": "Ampliar foto " + (i + 1) }, h("img", { src: f.src, alt: f.alt, class: f.ajuste === "natural" ? "natural" : f.ajuste ? "retrato" : null, loading: "lazy", decoding: "async" }));
      b.onclick = () => ver(i); return b;
    }));
    dlg.showModal(); dlg.scrollTop = 0;
  }
  function ver(i) {
    pos = (i + fotos.length) % fotos.length;
    $("#lbImg").src = fotos[pos].src; $("#lbImg").alt = fotos[pos].alt;
    $("#lbLegenda").textContent = fotos.length > 1 ? (pos + 1) + " de " + fotos.length : "";
    lb.querySelectorAll(".seta").forEach(s => s.hidden = fotos.length < 2);
    if (!lb.open) lb.showModal();
  }
  $("#lbAnt").onclick = () => ver(pos - 1); $("#lbProx").onclick = () => ver(pos + 1);
  lb.addEventListener("keydown", e => { if (e.key === "ArrowLeft") ver(pos - 1); if (e.key === "ArrowRight") ver(pos + 1); });
  document.querySelectorAll("dialog").forEach(d => d.addEventListener("click", e => { if (e.target === d || e.target.closest("[data-close]")) d.close(); }));
  document.querySelectorAll("dialog").forEach(d => d.addEventListener("close", () => d.querySelectorAll("video").forEach(v => v.pause())));

  /* Menu no celular */
  const mb = $("#menuBtn"), menu = $("#menu");
  mb.onclick = () => { const a = menu.classList.toggle("aberto"); mb.setAttribute("aria-expanded", a); };
  menu.addEventListener("click", e => { if (e.target.matches("a")) { menu.classList.remove("aberto"); mb.setAttribute("aria-expanded", false); } });

  /* SEO: lista os projetos para os buscadores */
  if (D.projetos.length) {
    const ld = $("#ld"), j = JSON.parse(ld.textContent);
    j.mainEntity = { "@type": "ItemList", itemListElement: D.projetos.map((p, i) => ({ "@type": "ListItem", position: i + 1, item: { "@type": "CreativeWork", name: p.titulo, description: p.descricao, about: p.categoria } })) };
    ld.textContent = JSON.stringify(j);
  }

  /* SEO: informa ao Google que existe um episódio de podcast */
  if (P.audio || P.embed) {
    const ld = $("#ld"), j = JSON.parse(ld.textContent);
    j.hasPart = [{ "@type": "PodcastEpisode", name: P.titulo, description: P.descricao }];
    ld.textContent = JSON.stringify(j);
  }

  desenhar(); revelar();
})();
