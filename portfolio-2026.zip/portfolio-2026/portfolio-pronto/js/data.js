/* ============================================================
   DADOS DO PORTFÓLIO — edite só este arquivo.
   O que está entre aspas "..." é texto que aparece no site.
   Mantenha as vírgulas e as aspas como estão.
   ============================================================ */
window.PORTFOLIO = {

  /* 1. INFORMAÇÕES GERAIS */
  site: {
    subtitulo: "Do carvão ao colete do cangaço, passando por pedras no chão, um fanzine e um podcast: o nosso ano, bimestre a bimestre.",
    grupo: "2º ano 3",
    instituicao: "Escola Estadual Senador João Bosco Ramos de Lima",
    ano: "2026",
    sobre: [
      "Somos quatro estudantes do 2º ano 3 e este portfólio guarda, em um só lugar, os registros do que fizemos nas atividades do ano letivo.",
      "Os trabalhos estão organizados por categoria e por bimestre. Clique em um deles para ler a descrição, ampliar as fotos e, quando houver, assistir aos vídeos. Os integrantes aparecem mais abaixo."
    ],
    encerramento: "Obrigado por ter chegado até aqui."
  },

  /* 2. CATEGORIAS. Os botões de filtro nascem desta lista; cada trabalho usa o mesmo nome escrito igual. */
  categorias: ["Desenho", "Ao ar livre", "Cultura e tradição", "Papel e palavra"],

  /* 3. INTEGRANTES. "foto" pode ficar vazio "": o site mostra as iniciais.
     "apresentacao" e "contribuicao" são opcionais: se ficarem vazios, não aparecem. */
  integrantes: [
    { id: "i1", nome: "Gustavo Alho Ferreira", apresentacao: "sou estudante do ensino médio e moro em Manaus, Amazonas. Sou uma pessoa reservada, observadora e sempre interessada em adquirir novos conhecimentos e desenvolver minhas habilidades. Valorizo muito o aprendizado contínuo e o desenvolvimento pessoal, buscando constantemente aprimorar minhas capacidades para conquistar minha independência e construir um futuro sólido. No meu tempo livre, tenho grande interesse por literatura, música, guitarra e atividades físicas.", contribuicao: "", foto: "" },
    { id: "i2", nome: "Octavio Augusto Ribeiro Pires", apresentacao: "Me chamo Octavio Augusto, tenho 17 anos, nascido e  vivendo em Manaus, estudo na escola Estadual Senador João Bosco Ramos de Lima e curso automação. Gostaria de buscar minha carreira com dedicação aos estudos e experiência. Sei falar Espanhol, um pouco de inglês e prático esportes, como futebol e futsal", contribuicao: "", foto: "assets/images/members/octavio-augusto.jpg", fotoAlt: "Octavio Augusto Ribeiro Pires, de camisa branca e cabelo cacheado, com a cabeça inclinada, diante de uma parede clara." },
    { id: "i3", nome: "Samuel Balieiro Freitas", apresentacao: "Gosto de aprender coisas novas e de aproveitar o tempo com o que me diverte e desperta minha curiosidade: jogar videogame, ler quadrinhos e mangás, assistir a animes e ouvir música. Também gosto de passar tempo com a família e os amigos, e de ler livros quando o assunto me interessa, porque a leitura estimula a imaginação. Procuro equilibrar estudos, lazer e convivência, aprender com os erros e evoluir a cada dia, para estar preparado para os desafios do futuro.", contribuicao: "", foto: "assets/images/members/samuel-balieiro.jpg", fotoAlt: "Samuel Balieiro Freitas, de camiseta preta e cabelo cacheado, em uma selfie no espelho redondo de um banheiro de paredes cinza, com o celular na mão e um relógio prateado no pulso." },
    { id: "i4", nome: "Samuel Isaac Rodriguez Filgueira", apresentacao: "Nasci em Puerto Ordaz, na Venezuela, onde passei parte da infância com minha família. Em 2020 vim para o Brasil por causa da crise política, da ditadura e da grave inflação no país, e desde então moro em Manaus, onde sigo os estudos. Busco construir meu futuro pela educação, pelo aprendizado e pelo desenvolvimento pessoal.", contribuicao: "", foto: "assets/images/members/samuel-isaac.jpg", fotoAlt: "Samuel Isaac Rodriguez Filgueira, de boné branco e casaco preto e branco, com um colar prateado, sentado em um banco de shopping, com plantas ao fundo." }
  ],

  /* 4. TRABALHOS. Campos opcionais: participantes: ["i1","i2"] (ids acima),
     videos: [{ src, poster, alt, legenda }], credito: "quem fez as imagens". Cada foto precisa de "alt" (descrição do que aparece). */
  projetos: [
      {
          "id": "visionboard",
          "titulo": "Visionboard",
          "categoria": "Papel e palavra",
          "bimestre": "1º bimestre",
          "descricao": "Quadro de metas para 2026: cada visionboard junta imagens e frases do que a pessoa quer conquistar no ano, como estudar mais, cuidar do corpo, aprender idiomas e juntar dinheiro. Aqui estão três versões, duas feitas à mão em papel e uma digital.",
          "objetivo": "Visualizar, em imagens e palavras, as metas pessoais para 2026.",
          "imagens": [
              {
                  "src": "assets/images/projects/visionboard/foto-1.jpg",
                  "alt": "Visionboard em cartolina azul com o título “Metas 2026” ao centro, cercado por dez fotos com legendas escritas à mão: cuidar do meu corpo, aprender algo novo, estudar mais, menos hábitos ruins, me expressar mais, atitude, saúde mental, cuidar de quem eu gosto, rotina e economizar."
              },
              {
                  "src": "assets/images/projects/visionboard/foto-2.jpg",
                  "alt": "Visionboard em papel branco com o título “Meu 2026”, assinado por Samuel Isaac, do 2º ano 3. As fotos coladas têm legendas como aprender inglês, ganhar o interclasse, aprender a cortar cabelo, conseguir o primeiro trabalho, organizar meu tempo, dedicar mais aos estudos e ganhar dinheiro."
              },
              {
                  "src": "assets/images/projects/visionboard/foto-3.jpg",
                  "alt": "Visionboard digital com o número 2026 no centro, cercado por imagens e frases como melhorar a alimentação, ler mais livros, fazer academia, ir no show, viajar, aprender novos idiomas, montar setup gamer e guardar dinheiro."
              }
          ]
      },
      {
          "id": "queimadas-na-amazonia",
          "titulo": "Queimadas na Amazônia",
          "categoria": "Desenho",
          "bimestre": "1º bimestre",
          "descricao": "Desenhos feitos com carvão sobre o tema das queimadas na Amazônia. Um mostra chamas altas sobre um fundo escuro e esfumaçado, outro uma pequena criatura em pé entre troncos de árvores, e o terceiro uma figura assustada diante de uma cerca, com árvores ao fundo.",
          "objetivo": "Representar em desenho, com carvão, o tema das queimadas na Amazônia.",
          "imagens": [
              {
                  "src": "assets/images/projects/queimadas-na-amazonia/foto-1.jpg",
                  "alt": "Desenho em carvão com chamas altas e pontudas, coloridas em tons suaves de amarelo e verde, sobre um fundo escuro esfumaçado; o papel está sobre uma mesa de madeira, ao lado de um livro amarelo."
              },
              {
                  "src": "assets/images/projects/queimadas-na-amazonia/foto-2.jpg",
                  "alt": "Desenho em carvão de uma pequena criatura arredondada, de pernas finas, em pé entre troncos de árvores altos e finos, sobre um fundo cinza esfumaçado."
              },
              {
                  "src": "assets/images/projects/queimadas-na-amazonia/foto-3.jpg",
                  "alt": "Desenho em carvão de uma figura de rosto assustado, com as mãos junto à cabeça, diante de uma cerca inclinada e de árvores ao fundo; o papel está sobre uma mesa de madeira."
              }
          ]
      },
      {
          "id": "land-art",
          "titulo": "Land Art",
          "categoria": "Ao ar livre",
          "bimestre": "2º bimestre",
          "descricao": "Obras de land art, a arte feita direto na natureza: pedras organizadas sobre o chão de terra formam linhas e desenhos que só existem naquele lugar. Uma das obras usa pedras em tons de terra, e a outra mistura pedrinhas pintadas de várias cores.",
          "objetivo": "Criar uma obra ao ar livre, usando pedras e o próprio chão como material.",
          "imagens": [
              {
                  "src": "assets/images/projects/land-art/foto-1.jpg",
                  "alt": "Land art de pedras claras e avermelhadas dispostas em linhas que se abrem a partir de um grupo central, sobre chão de terra com musgo, mato e folhas secas."
              },
              {
                  "src": "assets/images/projects/land-art/foto-2.jpg",
                  "alt": "Land art de pedrinhas marrons e pedrinhas pintadas de rosa, verde, azul, amarelo, branco e vermelho, dispostas em linhas curvas sobre o chão de terra, com mato na lateral."
              }
          ]
      },
      {
          "id": "ancestralidade",
          "titulo": "Ancestralidade",
          "categoria": "Cultura e tradição",
          "bimestre": "2º bimestre",
          "descricao": "Apresentação sobre “Um Índio”, música de Caetano Veloso lançada em 1977, que fala da ancestralidade e da cultura indígena. Os slides trazem a biografia do cantor e compositor e uma justificativa para cada trecho escolhido, explicando como ele trata da ligação dos povos indígenas com a natureza, da força dos antepassados e da permanência dessa identidade ao longo do tempo. Trabalho feito em grupo com duas colegas de turma.",
          "objetivo": "Interpretar, trecho por trecho, como a música trata da ancestralidade e da cultura indígena.",
          "participantes": [
              "i3",
              "i4"
          ],
          "imagens": [
              {
                  "src": "assets/images/projects/ancestralidade/foto-1.jpg",
                  "alt": "Slide de abertura com o título “Um índio” em uma caixa laranja e os nomes das quatro pessoas que fizeram a apresentação; à direita, a ilustração em silhueta escura de duas crianças indígenas dançando, com cocar, colares, pulseiras e um tambor, sobre um fundo de papel bege.",
                  "ajuste": "inteira"
              },
              {
                  "src": "assets/images/projects/ancestralidade/foto-2.jpg",
                  "alt": "Slide “Biografia” de Caetano Veloso: um texto sobre o cantor e compositor, nascido em Santo Amaro em 1942 e um dos nomes da Tropicália, ao lado de quatro fotos dele cantando e tocando violão em palcos, de camisa estampada, jaqueta jeans, roupa clara e camisa vermelha.",
                  "ajuste": "inteira"
              },
              {
                  "src": "assets/images/projects/ancestralidade/foto-3.jpg",
                  "alt": "Slide “Justificativas”: quatro trechos da música, cada um seguido de uma explicação de como ele trata da ancestralidade indígena, ligada aos elementos sagrados da natureza, aos espíritos da natureza, à permanência da identidade indígena ao longo do tempo e à herança presente em tudo o que existe.",
                  "ajuste": "inteira"
              }
          ]
      },
      {
          "id": "mostra-literaria",
          "titulo": "Mostra Literária",
          "categoria": "Papel e palavra",
          "bimestre": "2º bimestre",
          "descricao": "Trabalho feito pelos quatro integrantes. Os dois vídeos mostram o espaço da mostra, com as paredes decoradas por folhas verdes de papel e pequenas imagens e retratos.",
          "participantes": [
              "i1",
              "i2",
              "i3",
              "i4"
          ],
          "imagens": [],
          "videos": [
              {
                  "src": "assets/images/projects/mostra-literaria/video-1.mp4",
                  "poster": "assets/images/projects/mostra-literaria/poster-1.jpg",
                  "alt": "Parede bege de sala de aula enfeitada com folhas verdes de papel e pequenos retratos, acima de uma fileira de cadeiras azuis.",
                  "legenda": ""
              },
              {
                  "src": "assets/images/projects/mostra-literaria/video-2.mp4",
                  "poster": "assets/images/projects/mostra-literaria/poster-2.jpg",
                  "alt": "Corredor estreito com paredes decoradas por folhas verdes de papel e pequenas imagens, iluminado por luzes coloridas em roxo e verde.",
                  "legenda": ""
              }
          ]
      },
      {
          "id": "manifestacoes-culturais",
          "titulo": "Manifestações culturais",
          "categoria": "Desenho",
          "bimestre": "2º bimestre",
          "descricao": "Desenhos de movimentos que lembram a capoeira, manifestação cultural brasileira que mistura luta, dança e música. Um mostra dois homens em saltos acrobáticos no ar, e o outro um homem de cabeça para baixo, apoiado em uma só mão.",
          "objetivo": "Representar em desenho uma manifestação da cultura brasileira.",
          "imagens": [
              {
                  "src": "assets/images/projects/manifestacoes-culturais/foto-1.jpg",
                  "alt": "Desenho a lápis de cor de dois homens de calça branca e sem camisa em saltos acrobáticos no ar, em movimentos que lembram a capoeira; a folha traz a assinatura de Samuel Balieiro Freitas, 2º ano 3."
              },
              {
                  "src": "assets/images/projects/manifestacoes-culturais/foto-2.jpg",
                  "alt": "Desenho a lápis de um homem sem camisa, de calça branca com uma corda na cintura, de cabeça para baixo e apoiado em uma só mão, com uma perna esticada para o alto, em movimento que lembra a capoeira."
              }
          ]
      },
      {
          "id": "fanzine",
          "titulo": "Fanzine",
          "categoria": "Papel e palavra",
          "bimestre": "3º bimestre",
          "descricao": "Fanzines feitos à mão, em formato pequeno e com capa desenhada: publicações independentes, do tipo que qualquer pessoa pode criar sozinha. Um tem na capa um relógio e a palavra “Intestellar”; o outro se chama “A História de Will Smith e o Muro”.",
          "objetivo": "Criar uma publicação independente, feita à mão.",
          "imagens": [
              {
                  "src": "assets/images/projects/fanzine/foto-1.jpg",
                  "alt": "Capa de fanzine feita à mão, com o desenho de um relógio de doze quadradinhos com um só ponteiro e a palavra “INTESTELLAR” escrita embaixo, sobre folhas empilhadas.",
                  "ajuste": "natural"
              },
              {
                  "src": "assets/images/projects/fanzine/foto-2.jpg",
                  "alt": "Fanzine de capa vermelha desenhada como um muro de tijolos, com o título “A História de Will Smith e o Muro” em uma etiqueta branca e, abaixo, a assinatura “Samuel Isaac, 2 ano 3” em outra.",
                  "ajuste": "natural"
              }
          ]
      },
      {
          "id": "colete-do-cangaco",
          "titulo": "Colete do cangaço",
          "categoria": "Cultura e tradição",
          "bimestre": "3º bimestre",
          "descricao": "Coletes inspirados no cangaço, feitos pelos estudantes com recortes de folhas coloridas e outros materiais. As fotos acompanham três momentos: a produção, a apresentação à turma na sala de aula e a exposição, com os coletes vestidos em manequins em um salão com mesas de trabalhos.",
          "imagens": [
              {
                  "src": "assets/images/projects/colete-do-cangaco/foto-4.jpg",
                  "alt": "Manequim com colete preto enfeitado por círculos azul-turquesa, exposto em um salão amplo com mesas compridas; uma visitante de costas observa a peça e outras pessoas conversam ao fundo."
              },
              {
                  "src": "assets/images/projects/colete-do-cangaco/foto-1.jpg",
                  "alt": "Salão de exposição com janelas grandes, mesas compridas com trabalhos e, à esquerda, um manequim com colete roxo e uma estrela rosa; visitantes conversam ao fundo."
              },
              {
                  "src": "assets/images/projects/colete-do-cangaco/foto-2.jpg",
                  "alt": "Três estudantes de camisa vermelha e calça verde do uniforme, vestindo coletes coloridos com estrelas, apresentam o trabalho em frente ao quadro branco da sala; uma colega assiste em pé, à esquerda."
              },
              {
                  "src": "assets/images/projects/colete-do-cangaco/foto-3.jpg",
                  "alt": "Estudantes de calça verde do uniforme, sentados no chão, recortam com tesoura folhas coloridas, uma amarela em formato de espiral e outra vermelha brilhante, durante a produção dos coletes."
              }
          ]
      },
      {
          "id": "festival-folclorico",
          "titulo": "Festival Folclórico",
          "categoria": "Cultura e tradição",
          "bimestre": "3º bimestre",
          "descricao": "O festival aconteceu na quadra da escola, decorada com bandeirinhas e balões de festa junina. Nosso grupo participou colaborando com bandeirinhas e com um pudim de cupuaçu. As fotos mostram as apresentações da festa.",
          "objetivo": "Participar do Festival Folclórico da escola e mostrar como foi a festa.",
          "participantes": [
              "i1",
              "i2",
              "i3",
              "i4"
          ],
          "credito": "Fotos do perfil da escola no Instagram.",
          "imagens": [
              {
                  "src": "assets/images/projects/festival-folclorico/foto-1.jpg",
                  "alt": "Casal dançando descalço na quadra da escola: ela de vestido laranja de babados com estampa floral e uma flor laranja no cabelo, ele de chapéu de palha e roupa bege com detalhes laranja. Ao fundo, o painel do Festival Folclórico da escola, bandeirinhas, bonecos de palha e plateia sentada."
              },
              {
                  "src": "assets/images/projects/festival-folclorico/foto-2.jpg",
                  "alt": "Apresentação com fantasias de penas e pinturas corporais, de inspiração indígena: uma dançarina ao centro, de fantasia vermelha com enorme cocar de penas vermelhas e roxas, cercada por dançarinos ajoelhados de cocares brancos e amarelos, na quadra laranja. No teto, bandeirinhas coloridas e um balão de festa junina."
              },
              {
                  "src": "assets/images/projects/festival-folclorico/foto-3.jpg",
                  "alt": "Dançarina de vestido vermelho cheio de brilhos, com saia volumosa de babados e palha dourada e um chapéu de penas vermelhas, em frente a um boi branco de chifres grandes, feito de tecido, em primeiro plano; ao fundo, dançarinos de cocares de penas brancas e amarelas."
              }
          ],
      }
  ],

  /* 5. PODCAST. Use "audio" (arquivo MP3) OU "embed" (código de incorporação de outro serviço). */
  podcast: {
    titulo: "Chile: a sombra da ditadura",
    descricao: "O episódio trata de quando ocorreu a ditadura no Chile, entre 1973 e 1990, e de seus impactos políticos e sociais.",
    participantes: [],
    informacoes: [],
    audio: "assets/podcast/podcast.mp3",
    embed: "",
    capa: "assets/podcast/cover.jpg",
    capaAlt: "Capa do podcast “Chile: a sombra da ditadura”, em preto e branco: a bandeira do Chile e o palácio ao fundo, soldados, punhos erguidos com microfones e uma urna de plebiscito, com a faixa “1973 – 1990”."
  }
};
